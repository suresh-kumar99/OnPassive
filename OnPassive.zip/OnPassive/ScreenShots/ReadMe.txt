I have uploaded only the source code files of Angular and Springboot , not the dependent libraries and jars.

In JavaSource folder, java source code is there which is developed on Springboot.
Created one RestController for fetching the countries data from the web.

In AngularSource folder Angular source code is there, in which I have created one component
as viewcountries.component for displaying all the countries with some basic details. 
And when we click on a spefic Country, it will displays the below details
	
	Borders : All border details
	Languages : All lanuages with detailed info
	Flag : Displays the Country's flag image
	Currencies : All currencies with detailed info

I have also attached the screenshots in Screenshots folder. From those screenshots we can get an overview.
So please go through the screenshots.

